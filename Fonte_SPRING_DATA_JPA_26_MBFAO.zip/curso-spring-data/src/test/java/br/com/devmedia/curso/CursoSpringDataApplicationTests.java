package br.com.devmedia.curso;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = CursoSpringDataApplication.class)
public class CursoSpringDataApplicationTests {

	@Test
	public void contextLoads() {
	}

}
