import './chartJS';
import './easyPieChart';
import './sparkline';
